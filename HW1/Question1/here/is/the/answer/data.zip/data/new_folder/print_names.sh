#!/usr/bin/env bash
# Filename: print_names.sh

echo "Please type in your name:"
read new_name

echo "Alice"
echo "Bob"
echo "Cathy"
echo $new_name

